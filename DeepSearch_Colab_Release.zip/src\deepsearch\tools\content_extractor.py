"""
Deep Search Agent Swarm — Content Extractor
Extracts clean text from web pages using trafilatura.
Falls back to basic HTML parsing if trafilatura fails.
"""

import logging
import re
from typing import Optional, Dict, Any
from dataclasses import dataclass

import httpx

logger = logging.getLogger("deepsearch.tools.content_extractor")

# Request timeout (seconds)
REQUEST_TIMEOUT = 15.0

# User agent to avoid being blocked
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)


@dataclass
class ExtractedContent:
    """Extracted content from a web page."""
    url: str
    title: str
    text: str
    word_count: int
    success: bool
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "url": self.url,
            "title": self.title,
            "text": self.text,
            "word_count": self.word_count,
            "success": self.success,
            "error": self.error,
        }

    def truncated_text(self, max_chars: int = 5000) -> str:
        """Get text truncated to max_chars."""
        if len(self.text) <= max_chars:
            return self.text
        return self.text[:max_chars] + f"\n\n... [truncated, {self.word_count} words total]"


def extract_content(url: str, max_chars: int = 5000) -> ExtractedContent:
    """
    Extract clean text content from a URL.

    Uses trafilatura for high-quality extraction, falls back to
    basic HTML stripping if that fails.

    Args:
        url: The URL to extract content from
        max_chars: Maximum characters to return

    Returns:
        ExtractedContent with the extracted text
    """
    # Skip non-HTML URLs
    skip_extensions = ('.pdf', '.jpg', '.jpeg', '.png', '.gif', '.mp4', '.zip', '.rar')
    if any(url.lower().endswith(ext) for ext in skip_extensions):
        return ExtractedContent(
            url=url,
            title="",
            text="",
            word_count=0,
            success=False,
            error=f"Skipped non-HTML file: {url}",
        )

    try:
        # Fetch the page
        html = _fetch_page(url)
        if not html:
            return ExtractedContent(
                url=url, title="", text="", word_count=0,
                success=False, error="Failed to fetch page",
            )

        # Try trafilatura first (best quality)
        text, title = _extract_with_trafilatura(html, url)

        # Fallback to basic extraction
        if not text:
            text, title = _extract_basic(html)

        if not text:
            return ExtractedContent(
                url=url, title=title or "", text="", word_count=0,
                success=False, error="No text content extracted",
            )

        # Clean and truncate
        text = _clean_text(text)
        if len(text) > max_chars:
            text = text[:max_chars]

        word_count = len(text.split())

        logger.info(f"Extracted {word_count} words from {url[:60]}...")
        return ExtractedContent(
            url=url,
            title=title or "",
            text=text,
            word_count=word_count,
            success=True,
        )

    except Exception as e:
        logger.warning(f"Content extraction failed for {url[:60]}: {e}")
        return ExtractedContent(
            url=url, title="", text="", word_count=0,
            success=False, error=str(e),
        )


def _fetch_page(url: str) -> Optional[str]:
    """Fetch a web page's HTML."""
    try:
        from scrapling.fetchers import StealthyFetcher
        logger.info(f"Using Scrapling StealthyFetcher to fetch: {url[:60]}...")
        # Open headless browser and fetch the page stealthily
        page = StealthyFetcher.fetch(url, headless=True)
        if page:
            if hasattr(page, 'text') and page.text:
                return page.text
            elif hasattr(page, 'body') and page.body:
                return page.body.decode('utf-8', errors='replace')
            else:
                return str(page)
    except Exception as e:
        logger.warning(f"Scrapling fetch failed for {url[:60]}, falling back to httpx: {e}")
    
    # Fallback to standard httpx if Scrapling fails or is unavailable
    try:
        with httpx.Client(
            timeout=REQUEST_TIMEOUT,
            follow_redirects=True,
            headers={"User-Agent": USER_AGENT},
        ) as client:
            response = client.get(url)
            response.raise_for_status()

            # Check content type
            content_type = response.headers.get("content-type", "")
            if "text/html" not in content_type and "text/plain" not in content_type:
                if "application/json" in content_type:
                    return response.text
                return None

            return response.text

    except Exception as e:
        logger.debug(f"Failed to fetch {url[:60]}: {e}")
        return None


def _extract_with_trafilatura(html: str, url: str) -> tuple:
    """Extract text using trafilatura."""
    try:
        import trafilatura

        result = trafilatura.extract(
            html,
            url=url,
            include_comments=False,
            include_tables=True,
            no_fallback=False,
            favor_recall=True,
        )

        title = ""
        try:
            metadata = trafilatura.extract_metadata(html, default_url=url)
            if metadata and metadata.title:
                title = metadata.title
        except Exception:
            pass

        return result or "", title

    except ImportError:
        logger.warning("trafilatura not installed, falling back to basic extraction")
        return "", ""
    except Exception as e:
        logger.debug(f"trafilatura extraction failed: {e}")
        return "", ""


def _extract_basic(html: str) -> tuple:
    """Basic HTML text extraction fallback."""
    title = ""
    title_match = re.search(r'<title[^>]*>(.*?)</title>', html, re.IGNORECASE | re.DOTALL)
    if title_match:
        title = title_match.group(1).strip()

    # Remove scripts and styles
    text = re.sub(r'<script[^>]*>[\s\S]*?</script>', '', html, flags=re.IGNORECASE)
    text = re.sub(r'<style[^>]*>[\s\S]*?</style>', '', text, flags=re.IGNORECASE)

    # Remove HTML tags
    text = re.sub(r'<[^>]+>', ' ', text)

    # Decode HTML entities
    text = re.sub(r'&amp;', '&', text)
    text = re.sub(r'&lt;', '<', text)
    text = re.sub(r'&gt;', '>', text)
    text = re.sub(r'&quot;', '"', text)
    text = re.sub(r'&#\d+;', '', text)
    text = re.sub(r'&\w+;', '', text)

    return text.strip(), title


def _clean_text(text: str) -> str:
    """Clean extracted text."""
    # Normalize whitespace
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r' {2,}', ' ', text)
    text = re.sub(r'\t+', ' ', text)

    # Remove very short lines (likely nav items)
    lines = text.split('\n')
    cleaned_lines = []
    for line in lines:
        stripped = line.strip()
        if len(stripped) > 2 or stripped == '':
            cleaned_lines.append(line)

    return '\n'.join(cleaned_lines).strip()
