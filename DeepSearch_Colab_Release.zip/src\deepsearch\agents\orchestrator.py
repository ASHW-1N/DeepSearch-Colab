"""
Deep Search Agent Swarm — Orchestrator Agent
Dynamically plans and creates specialized agents based on the query.
The 'brain' of the swarm — inspired by MiroFish's dynamic agent patterns.
"""

import json
import logging
from typing import Dict, Any, List, Optional, Callable

from ..config import Config
from ..llm_client import LLMClient
from ..tools.knowledge_base import KnowledgeBase
from ..prompts.agent_prompts import (
    ORCHESTRATOR_DECOMPOSE_PROMPT,
    ORCHESTRATOR_DECOMPOSE_USER,
    ORCHESTRATOR_GAP_ANALYSIS_PROMPT,
)

logger = logging.getLogger("deepsearch.agents.orchestrator")


class AgentSpec:
    """A dynamically created agent specification."""
    def __init__(self, id: str, name: str, role: str, focus: str, queries: List[str]):
        self.id = id
        self.name = name
        self.role = role
        self.focus = focus
        self.queries = queries

    def to_dict(self) -> dict:
        return {"id": self.id, "name": self.name, "role": self.role,
                "focus": self.focus, "queries": self.queries}


class OrchestratorAgent:
    """
    The Orchestrator dynamically plans what agents to create based on the query.
    Instead of hardcoded Searcher/Analyzer/Reporter roles, it asks the LLM to
    design specialized agents with unique names, roles, and focus areas.
    """

    def __init__(self, llm: LLMClient, knowledge_base: KnowledgeBase,
                 on_event: Optional[Callable] = None):
        self.llm = llm
        self.kb = knowledge_base
        self.search_round = 0
        self.on_event = on_event or (lambda **kw: None)

    def _emit(self, **kwargs):
        self.on_event(**kwargs)

    def plan_agents(self, query: str) -> List[AgentSpec]:
        """
        Dynamically plan specialized agents based on the query.
        Returns a list of AgentSpec objects — each becomes a searcher with a unique persona.
        """
        self._emit(phase="planning", agent="Orchestrator",
                   thought="Analyzing your query and designing specialized agents...",
                   progress=5)

        messages = [
            {"role": "system", "content": ORCHESTRATOR_DECOMPOSE_PROMPT},
            {"role": "user", "content": ORCHESTRATOR_DECOMPOSE_USER.format(query=query)},
        ]

        result = self.llm.chat_json(messages=messages, temperature=0.4)

        agents_data = result.get("agents", [])
        plan_summary = result.get("plan_summary", "")

        if not agents_data:
            logger.warning("Agent planning returned no agents, using fallback")
            agents_data = [
                {"id": "general", "name": "General Researcher",
                 "role": "Broad web research", "focus": "general coverage",
                 "queries": [f"What is {query}?", f"Latest developments in {query}",
                             f"Expert opinions on {query}"]},
                {"id": "critical", "name": "Critical Analyst",
                 "role": "Contrarian and critical viewpoints", "focus": "criticism and debate",
                 "queries": [f"Controversies about {query}", f"Problems with {query}"]},
            ]

        specs = []
        for a in agents_data:
            specs.append(AgentSpec(
                id=a.get("id", f"agent_{len(specs)}"),
                name=a.get("name", f"Agent {len(specs)+1}"),
                role=a.get("role", "General researcher"),
                focus=a.get("focus", "broad coverage"),
                queries=a.get("queries", []),
            ))

        # Store all queries as sub-questions in the KB
        all_queries = []
        for s in specs:
            all_queries.extend(s.queries)
        self.kb.set_sub_questions(all_queries)

        self._emit(phase="planning", agent="Orchestrator",
                   thought=f"Created {len(specs)} specialized agents: {', '.join(s.name for s in specs)}",
                   progress=10, data={"plan_summary": plan_summary,
                                       "agents": [s.to_dict() for s in specs]})

        logger.info(f"Planned {len(specs)} dynamic agents")
        for s in specs:
            logger.info(f"  {s.name} ({s.role}) — {len(s.queries)} queries")

        return specs

    # Keep backward compat
    def decompose_query(self, query: str) -> List[str]:
        specs = self.plan_agents(query)
        all_q = []
        for s in specs:
            all_q.extend(s.queries)
        return all_q

    def analyze_gaps(self, query: str) -> Dict[str, Any]:
        """Analyze what's missing from the research so far."""
        self.search_round += 1
        stats = self.kb.get_stats()

        self._emit(phase="analyzing", agent="Orchestrator",
                   thought="Checking research coverage and identifying knowledge gaps...",
                   progress=-1)

        findings = self.kb.get_findings()
        covered = set()
        for f in findings:
            if f.sub_question:
                covered.add(f.sub_question)

        findings_summary = self.kb.get_all_findings_text(max_chars=8000)

        prompt = ORCHESTRATOR_GAP_ANALYSIS_PROMPT.format(
            query=query,
            findings_summary=findings_summary,
            finding_count=stats["total_findings"],
            unique_sources=stats["unique_sources"],
            covered_questions=f"{len(covered)}/{len(self.kb.get_sub_questions())}",
            search_rounds=self.search_round,
            max_rounds=Config.MAX_SEARCH_ROUNDS,
        )

        messages = [
            {"role": "system", "content": "You are a research gap analyst. Return JSON only."},
            {"role": "user", "content": prompt},
        ]

        try:
            result = self.llm.chat_json(messages=messages, temperature=0.3)
        except Exception as e:
            logger.warning(f"Gap analysis LLM call failed: {e}")
            result = {
                "coverage_score": 5, "gaps": [], "new_sub_questions": [],
                "should_continue": self.search_round < Config.MAX_SEARCH_ROUNDS,
                "reasoning": f"LLM call failed, defaulting to continue: {e}",
            }

        if self.search_round >= Config.MAX_SEARCH_ROUNDS:
            result["should_continue"] = False

        coverage = result.get("coverage_score", "?")
        self._emit(phase="analyzing", agent="Orchestrator",
                   thought=f"Coverage: {coverage}/10. {'Continuing search...' if result.get('should_continue') else 'Coverage sufficient.'}",
                   progress=-1)

        logger.info(
            f"Gap analysis round {self.search_round}: "
            f"coverage={coverage}/10, "
            f"continue={result.get('should_continue', False)}, "
            f"new_questions={len(result.get('new_sub_questions', []))}"
        )

        return result

    def get_search_assignments(self, sub_questions: List[str], num_searchers: int = 2) -> List[List[str]]:
        """Divide sub-questions among searcher agents."""
        unsearched = [q for q in sub_questions if not self.kb.was_query_searched(q)]

        if not unsearched:
            return [[] for _ in range(num_searchers)]

        assignments = [[] for _ in range(num_searchers)]
        for i, q in enumerate(unsearched):
            assignments[i % num_searchers].append(q)

        return assignments
