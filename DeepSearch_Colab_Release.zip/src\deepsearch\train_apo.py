import os
import sys
import json
import asyncio
from typing import TypedDict, List, cast

from pydantic import BaseModel
from openai import AsyncOpenAI
import agentlightning 
from agentlightning.litagent import rollout
from agentlightning.algorithm.apo import APO
from agentlightning.runner import LitAgentRunner
from agentlightning.store import InMemoryLightningStore
from agentlightning.adapter import TraceToMessages
from agentlightning.types import Dataset, PromptTemplate
from agentlightning import Trainer, setup_logging

from deepsearch.config import Config, PROJECT_ROOT
from deepsearch.main import run_deep_search
from deepsearch.evals.reward import evaluate_hallucination
from deepsearch.prompts.agent_prompts import REPORTER_SYSTEM_PROMPT

class TaskInput(TypedDict):
    query: str

class ResearchTask(TypedDict):
    id: str
    task_input: TaskInput
    expected_facts: List[str]

def load_dataset() -> Dataset[ResearchTask]:
    tasks = []
    dataset_path = os.path.join(PROJECT_ROOT, "src", "deepsearch", "evals", "dataset.jsonl")
    with open(dataset_path, "r", encoding="utf-8") as f:
        for line in f:
            tasks.append(ResearchTask(**json.loads(line)))
    return cast(Dataset[ResearchTask], tasks)

@rollout
def ds_research_agent(task: ResearchTask, prompt_template: PromptTemplate) -> float:
    """Agent Lightning Rollout Hook"""
    query = task["task_input"]["query"]
    print(f"\\n--- Starting Rollout for: {query} ---")
    
    try:
        # Run the deepsearch pipeline, injecting the dynamically tuned reporter prompt
        report_path = run_deep_search(
            query=query, 
            max_rounds=2, 
            num_searchers=1, # Keep small for quick proxy traces
            reporter_prompt_template=prompt_template
        )
        
        # Read final report back
        with open(report_path, "r", encoding="utf-8") as f:
            report_text = f.read()
    except Exception as e:
        print(f"Error during deepsearch rollout: {e}")
        return 0.0
        
    score = evaluate_hallucination(report_text, task["expected_facts"])
    print(f"--- Rollout Complete! Score: {score} ---\\n")
    return score

def main():
    setup_logging()
    # Configure logging for APO specifically
    import logging
    logging.getLogger("agentlightning.algorithm.apo").setLevel(logging.INFO)

    # Resolve backend settings (colab vs openrouter)
    Config.validate()

    dataset = load_dataset()

    # Use AsyncOpenAI pointing to whichever backend is configured
    openai_client = AsyncOpenAI(
        api_key=Config.GROQ_API_KEY,
        base_url=Config.GROQ_BASE_URL,
    )

    # Initialize APO Algorithm
    algo = APO[ResearchTask](
        openai_client,
        val_batch_size=2,
        gradient_batch_size=1,
        beam_width=1,
        branch_factor=1,
        beam_rounds=1, # Keep strict bounds for testing
        _poml_trace=True,
    )

    trainer = Trainer(
        algorithm=algo,
        n_runners=1, # No concurrency to prevent API rate limits initially
        initial_resources={
            "prompt_template": PromptTemplate(
                template=REPORTER_SYSTEM_PROMPT,
                engine="f-string",
            )
        },
        adapter=TraceToMessages(),
    )

    # We use validation dataset as train for this tiny example
    trainer.fit(agent=ds_research_agent, train_dataset=dataset[:1], val_dataset=dataset)

if __name__ == "__main__":
    main()
