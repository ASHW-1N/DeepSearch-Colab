"""
Deep Search Agent Swarm — Knowledge Base
Thread-safe in-memory knowledge store shared by all agents.
Persists to JSON for recovery and inspection.

Inspired by MiroFish's Zep graph memory, but simplified for
our use case (no external service dependency).
"""

import os
import json
import time
import threading
import hashlib
import logging
from typing import List, Dict, Any, Optional, Set
from dataclasses import dataclass, field, asdict
from datetime import datetime

logger = logging.getLogger("deepsearch.tools.knowledge_base")


@dataclass
class Finding:
    """A single research finding with its source."""
    id: str                          # Unique ID (hash of content)
    content: str                     # The finding text
    source_url: str                  # Source URL (required — anti-hallucination)
    source_title: str                # Source page title
    sub_question: str                # Which sub-question this answers
    confidence: float                # 0.0-1.0, boosted by cross-referencing
    agent_id: str                    # Which agent found this
    timestamp: str                   # When it was found
    tags: List[str] = field(default_factory=list)       # Topic tags
    corroborated_by: List[str] = field(default_factory=list)  # IDs of supporting findings
    focus_score: float = 10.0        # Relevance to original query (0-10)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @staticmethod
    def make_id(content: str, source_url: str) -> str:
        """Generate a deterministic ID from content + source."""
        raw = f"{content[:200]}|{source_url}"
        return hashlib.md5(raw.encode()).hexdigest()[:12]


@dataclass
class SearchRecord:
    """Record of a search that was performed (prevents re-searching)."""
    query: str
    engine: str
    timestamp: str
    result_count: int
    urls_found: List[str] = field(default_factory=list)


class KnowledgeBase:
    """
    Thread-safe shared knowledge base for the agent swarm.

    All agents read/write to this. It provides:
    - Deduplication of findings
    - Cross-referencing (boost confidence when multiple sources agree)
    - Focus tracking (keep findings on-topic)
    - Search history (prevent duplicate searches)
    - Persistence to JSON file
    """

    def __init__(self, output_dir: str, original_query: str):
        self.output_dir = output_dir
        self.original_query = original_query

        self._findings: Dict[str, Finding] = {}      # id -> Finding
        self._search_history: List[SearchRecord] = []
        self._extracted_urls: Set[str] = set()        # URLs already read
        self._sub_questions: List[str] = []           # Decomposed sub-questions
        self._lock = threading.RLock()

        # Stats
        self._start_time = time.time()

        os.makedirs(output_dir, exist_ok=True)

    # ── Findings Management ──

    def add_finding(self, finding: Finding) -> bool:
        """
        Add a finding to the knowledge base.
        Returns True if added (new), False if duplicate.
        """
        with self._lock:
            # Check for duplicates
            if finding.id in self._findings:
                # If duplicate, boost the existing finding's confidence
                existing = self._findings[finding.id]
                if finding.agent_id not in existing.corroborated_by:
                    existing.corroborated_by.append(finding.agent_id)
                    existing.confidence = min(1.0, existing.confidence + 0.1)
                return False

            # Check for similar content (fuzzy dedup)
            for existing in self._findings.values():
                if self._is_similar(finding.content, existing.content):
                    existing.corroborated_by.append(finding.agent_id)
                    existing.confidence = min(1.0, existing.confidence + 0.15)
                    return False

            self._findings[finding.id] = finding
            self._auto_save()
            return True

    def get_findings(
        self,
        min_confidence: float = 0.0,
        min_focus_score: float = 0.0,
        sub_question: Optional[str] = None,
        limit: int = 100,
    ) -> List[Finding]:
        """Get findings filtered by criteria."""
        with self._lock:
            results = []
            for f in self._findings.values():
                if f.confidence >= min_confidence and f.focus_score >= min_focus_score:
                    if sub_question is None or f.sub_question == sub_question:
                        results.append(f)

            # Sort by confidence (highest first)
            results.sort(key=lambda x: x.confidence, reverse=True)
            return results[:limit]

    def get_all_findings_text(self, max_chars: int = 15000) -> str:
        """Get all findings as a formatted text string for LLM context."""
        with self._lock:
            findings = sorted(
                self._findings.values(),
                key=lambda x: x.confidence,
                reverse=True,
            )

            parts = []
            total_chars = 0
            for i, f in enumerate(findings, 1):
                entry = (
                    f"{i}. [{f.source_title}]({f.source_url})\n"
                    f"   Confidence: {f.confidence:.1f} | "
                    f"Focus: {f.focus_score:.0f}/10\n"
                    f"   {f.content}\n"
                )
                if total_chars + len(entry) > max_chars:
                    parts.append(f"\n... ({len(findings) - i} more findings truncated)")
                    break
                parts.append(entry)
                total_chars += len(entry)

            return "\n".join(parts) if parts else "(No findings yet)"

    @property
    def finding_count(self) -> int:
        with self._lock:
            return len(self._findings)

    # ── Search History ──

    def record_search(self, query: str, engine: str, urls: List[str]):
        """Record that a search was performed."""
        with self._lock:
            self._search_history.append(SearchRecord(
                query=query,
                engine=engine,
                timestamp=datetime.now().isoformat(),
                result_count=len(urls),
                urls_found=urls,
            ))

    def was_query_searched(self, query: str) -> bool:
        """Check if a similar query was already searched."""
        with self._lock:
            query_lower = query.lower().strip()
            for record in self._search_history:
                if record.query.lower().strip() == query_lower:
                    return True
                # Fuzzy match — if 80% of words overlap
                q_words = set(query_lower.split())
                r_words = set(record.query.lower().strip().split())
                if q_words and r_words:
                    overlap = len(q_words & r_words) / max(len(q_words), len(r_words))
                    if overlap > 0.8:
                        return True
            return False

    # ── URL Tracking ──

    def mark_url_extracted(self, url: str):
        """Mark a URL as having been content-extracted."""
        with self._lock:
            self._extracted_urls.add(url)

    def was_url_extracted(self, url: str) -> bool:
        """Check if a URL has already been content-extracted."""
        with self._lock:
            return url in self._extracted_urls

    # ── Sub-Questions ──

    def set_sub_questions(self, questions: List[str]):
        """Set the decomposed sub-questions."""
        with self._lock:
            self._sub_questions = questions

    def get_sub_questions(self) -> List[str]:
        with self._lock:
            return list(self._sub_questions)

    # ── Stats ──

    def get_stats(self) -> Dict[str, Any]:
        """Get knowledge base statistics."""
        with self._lock:
            findings = list(self._findings.values())
            avg_confidence = (
                sum(f.confidence for f in findings) / len(findings)
                if findings else 0
            )
            corroborated = sum(1 for f in findings if f.corroborated_by)
            unique_sources = len(set(f.source_url for f in findings))

            return {
                "total_findings": len(findings),
                "avg_confidence": round(avg_confidence, 2),
                "corroborated_findings": corroborated,
                "unique_sources": unique_sources,
                "searches_performed": len(self._search_history),
                "urls_extracted": len(self._extracted_urls),
                "sub_questions": len(self._sub_questions),
                "elapsed_seconds": round(time.time() - self._start_time, 1),
            }

    # ── Persistence ──

    def _auto_save(self):
        """Auto-save to JSON (called internally after modifications)."""
        try:
            self.save()
        except Exception as e:
            logger.debug(f"Auto-save failed: {e}")

    def save(self):
        """Save knowledge base to JSON file."""
        filepath = os.path.join(self.output_dir, "knowledge_base.json")
        data = {
            "original_query": self.original_query,
            "stats": self.get_stats(),
            "sub_questions": self._sub_questions,
            "findings": [f.to_dict() for f in self._findings.values()],
            "search_history": [asdict(s) for s in self._search_history],
            "extracted_urls": list(self._extracted_urls),
            "saved_at": datetime.now().isoformat(),
        }
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    # ── Helpers ──

    @staticmethod
    def _is_similar(text1: str, text2: str, threshold: float = 0.7) -> bool:
        """Check if two texts are similar (simple word overlap)."""
        words1 = set(text1.lower().split()[:50])
        words2 = set(text2.lower().split()[:50])
        if not words1 or not words2:
            return False
        overlap = len(words1 & words2) / min(len(words1), len(words2))
        return overlap > threshold
