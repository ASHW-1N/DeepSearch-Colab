"""
Deep Search Agent Swarm — Base Agent
ReACT agent loop pattern adapted from MiroFish's ReportAgent.
Think → Act (tool call) → Observe (result) → Decide.
"""

import re
import json
import logging
from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass

try:
    from agentlightning import emit_message as _emit_message, emit_object as _emit_object
    _HAS_AGL = True
except (ImportError, Exception):
    _HAS_AGL = False

def _safe_emit_message(*args, **kwargs):
    """Emit a trace message if Agent Lightning tracer is active, otherwise skip."""
    if not _HAS_AGL:
        return
    try:
        _emit_message(*args, **kwargs)
    except Exception:
        pass  # No active tracer or API mismatch — skip silently

def _safe_emit_object(*args, **kwargs):
    """Emit a trace object if Agent Lightning tracer is active, otherwise skip."""
    if not _HAS_AGL:
        return
    try:
        _emit_object(*args, **kwargs)
    except Exception:
        pass  # No active tracer or API mismatch — skip silently

logger = logging.getLogger("deepsearch.agents.base")


@dataclass
class ToolCall:
    """Parsed tool call from LLM response."""
    name: str
    parameters: Dict[str, Any]


class BaseAgent:
    """
    Base class for all Deep Search agents.

    Implements the ReACT (Reasoning + Acting) loop:
    1. Think: The LLM reasons about what to do
    2. Act: It calls a tool
    3. Observe: The tool returns results
    4. Decide: Continue or finish

    Subclasses define available tools and their implementations.
    """

    def __init__(
        self,
        agent_id: str,
        llm_client,
        max_iterations: int = 8,
        model: Optional[str] = None,
    ):
        self.agent_id = agent_id
        self.llm = llm_client
        self.max_iterations = max_iterations
        self.model = model  # Override model selection
        self.conversation: List[Dict[str, str]] = []
        self.tool_calls_made = 0

    def run_react_loop(
        self,
        system_prompt: str,
        user_prompt: str,
        on_thought: Optional[Callable] = None,
        on_tool_call: Optional[Callable] = None,
    ) -> str:
        """
        Run the ReACT loop.

        Args:
            system_prompt: System instructions
            user_prompt: Initial user message
            on_thought: Callback when agent thinks
            on_tool_call: Callback when agent uses a tool

        Returns:
            Final result text or last response
        """
        self.conversation = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]
        _safe_emit_message(system_prompt, attributes={"role": "system"})
        _safe_emit_message(user_prompt, attributes={"role": "user"})

        for iteration in range(1, self.max_iterations + 1):
            # Get LLM response
            try:
                response = self.llm.chat(
                    messages=self.conversation,
                    model=self.model,
                    temperature=0.4,
                    max_tokens=4096,
                )
                _safe_emit_message(response, attributes={"role": "assistant"})
            except Exception as e:
                logger.error(f"[{self.agent_id}] LLM call failed at iteration {iteration}: {e}")
                break

            if on_thought:
                on_thought(self.agent_id, iteration, response[:200])

            # Check if agent is done
            if self._is_done(response):
                logger.info(f"[{self.agent_id}] Finished after {iteration} iterations")
                return self._extract_final_answer(response)

            # Try to parse a tool call
            tool_call = self._parse_tool_call(response)
            if tool_call:
                _safe_emit_object(f"Call Tool: {tool_call.name}", obj=tool_call.parameters, attributes={"tool": tool_call.name})
                if on_tool_call:
                    on_tool_call(self.agent_id, tool_call.name, tool_call.parameters)

                # Execute the tool
                try:
                    result = self.execute_tool(tool_call.name, tool_call.parameters)
                    self.tool_calls_made += 1
                    _safe_emit_message(f"Tool Result ({len(result.split())} words)", attributes={"tool": tool_call.name, "result": result[:500] + "..."})
                except Exception as e:
                    result = f"Tool error: {str(e)}"
                    logger.warning(f"[{self.agent_id}] Tool '{tool_call.name}' failed: {e}")

                # Add to conversation: assistant's response + tool result
                self.conversation.append({"role": "assistant", "content": response})
                self.conversation.append({
                    "role": "user",
                    "content": f"Observation (tool '{tool_call.name}' returned):\n\n{result}",
                })
            else:
                # No tool call and not done — add response and nudge
                self.conversation.append({"role": "assistant", "content": response})
                self.conversation.append({
                    "role": "user",
                    "content": (
                        "Please either call a tool using <tool_call> format, "
                        "or output DONE if you have finished your task."
                    ),
                })

        logger.warning(f"[{self.agent_id}] Hit max iterations ({self.max_iterations})")
        return self._get_last_substantive_response()

    def execute_tool(self, tool_name: str, parameters: Dict[str, Any]) -> str:
        """
        Execute a tool. Override in subclasses to define tools.

        Args:
            tool_name: Name of the tool
            parameters: Tool parameters

        Returns:
            Tool result as string
        """
        raise NotImplementedError(
            f"Tool '{tool_name}' not implemented in {self.__class__.__name__}"
        )

    # ── Parsing Helpers ──

    def _parse_tool_call(self, response: str) -> Optional[ToolCall]:
        """Parse a tool call from the LLM response."""
        # Look for <tool_call> tags
        match = re.search(
            r'<tool_call>\s*(.*?)\s*</tool_call>',
            response,
            re.DOTALL,
        )
        if not match:
            # Also try ```json blocks as fallback
            match = re.search(
                r'```(?:json)?\s*(\{[^`]*"name"\s*:[^`]*\})\s*```',
                response,
                re.DOTALL,
            )
            
        if not match:
            # Try raw JSON fallback (LLM might just output a JSON object without tags)
            json_match = re.search(r'(\{.*"name"\s*:.*"parameters"\s*:.*\})', response, re.DOTALL)
            if json_match:
                try:
                    data = json.loads(json_match.group(1))
                    return ToolCall(
                        name=data.get("name", ""),
                        parameters=data.get("parameters", {}),
                    )
                except (json.JSONDecodeError, KeyError):
                    pass

            return None

        try:
            data = json.loads(match.group(1))
            return ToolCall(
                name=data.get("name", ""),
                parameters=data.get("parameters", {}),
            )
        except (json.JSONDecodeError, KeyError):
            return None

    def _is_done(self, response: str) -> bool:
        """Check if the agent signals completion."""
        # Check for explicit DONE signal
        if re.search(r'\bDONE\b', response):
            # Make sure it's not inside a tool call or explanation
            if '<tool_call>' not in response:
                return True

        # Check for "Final Answer:" pattern (MiroFish style)
        if 'Final Answer:' in response:
            return True

        return False

    def _extract_final_answer(self, response: str) -> str:
        """Extract the final answer from a response."""
        # Try to get content after "Final Answer:"
        match = re.search(r'Final Answer:\s*(.*)', response, re.DOTALL)
        if match:
            return match.group(1).strip()

        # Otherwise return the full response, minus any DONE markers
        return response.replace('DONE', '').strip()

    def _get_last_substantive_response(self) -> str:
        """Get the last substantive assistant response."""
        for msg in reversed(self.conversation):
            if msg["role"] == "assistant" and len(msg["content"]) > 50:
                return msg["content"]
        return ""
