"""Entry point for `python -m deepsearch`."""
from deepsearch.main import main

if __name__ == "__main__":
    main()
