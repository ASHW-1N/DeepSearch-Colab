"""
Deep Search Agent Swarm — Reporter Agent
Generates the final comprehensive research report with footnote-style citations.
No raw metadata is included in the report body.
"""

import os
import logging
from typing import Dict, Any, Optional
from datetime import datetime

from ..config import Config
from ..llm_client import LLMClient
from ..tools.knowledge_base import KnowledgeBase
from ..prompts.agent_prompts import REPORTER_SYSTEM_PROMPT, REPORTER_USER_PROMPT

logger = logging.getLogger("deepsearch.agents.reporter")


class ReporterAgent:
    """
    The Reporter generates a clean, professional markdown report.
    Uses footnote-style [1] [2] annotations instead of raw inline URLs.
    No raw metadata (token counts, durations, etc.) appears in the report.
    """

    def __init__(self, llm: LLMClient, knowledge_base: KnowledgeBase, original_query: str):
        self.llm = llm
        self.kb = knowledge_base
        self.original_query = original_query

    def generate_report(
        self,
        contradictions: str = "",
        gaps: str = "",
        search_rounds: int = 0,
        prompt_template: Optional[Any] = None,
    ) -> str:
        """Generate the final research report (clean, no metadata)."""
        stats = self.kb.get_stats()
        findings_text = self.kb.get_all_findings_text(max_chars=12000)

        user_prompt = REPORTER_USER_PROMPT.format(
            original_query=self.original_query,
            findings_text=findings_text,
            contradictions=contradictions or "None identified.",
            gaps=gaps or "None identified.",
        )

        system_prompt = REPORTER_SYSTEM_PROMPT
        if prompt_template:
            # Note: We simulate PromptTemplate rendering assuming it doesn't need external variables 
            # or just string casts.
            system_prompt = getattr(prompt_template, "template", getattr(prompt_template, "content", REPORTER_SYSTEM_PROMPT))

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        logger.info("Generating final report...")

        report = self.llm.chat(
            messages=messages,
            model=Config.BIG_MODEL,
            temperature=0.5,
            max_tokens=8000,
        )

        # Return clean report — NO metadata header, NO source appendix
        # The LLM itself generates the References section with footnotes
        return report

    def save_report(self, report: str, filename: Optional[str] = None) -> str:
        """Save the report to a markdown file."""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_query = "".join(
                c if c.isalnum() or c in (' ', '-', '_') else '_'
                for c in self.original_query[:50]
            ).strip().replace(' ', '_')
            filename = f"report_{safe_query}_{timestamp}.md"

        filepath = os.path.join(Config.OUTPUT_DIR, filename)
        os.makedirs(os.path.dirname(filepath), exist_ok=True)

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(report)

        logger.info(f"Report saved to: {filepath}")
        return filepath
