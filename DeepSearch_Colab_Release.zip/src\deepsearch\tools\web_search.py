"""
Deep Search Agent Swarm — Web Search Tools
Free web search using ddgs (DuckDuckGo Search — no API key required).
Includes rate-limit protection to avoid 403 blocks.
"""

import time
import logging
import threading
from typing import List, Dict, Any, Optional
from dataclasses import dataclass

logger = logging.getLogger("deepsearch.tools.web_search")

# Global rate limiter — DuckDuckGo blocks rapid-fire requests
_search_lock = threading.Lock()
_last_search_time = 0.0
_MIN_DELAY_SECONDS = 2.0  # Minimum gap between any two searches


def _rate_limit():
    """Enforce minimum delay between searches to avoid 403 rate limits."""
    global _last_search_time
    with _search_lock:
        now = time.time()
        elapsed = now - _last_search_time
        if elapsed < _MIN_DELAY_SECONDS:
            wait = _MIN_DELAY_SECONDS - elapsed
            logger.debug(f"Rate limiter: waiting {wait:.1f}s before next search")
            time.sleep(wait)
        _last_search_time = time.time()


@dataclass
class SearchResult:
    """A single search result."""
    title: str
    url: str
    snippet: str
    source: str = "duckduckgo"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "url": self.url,
            "snippet": self.snippet,
            "source": self.source,
        }

    def __str__(self) -> str:
        return f"[{self.title}]({self.url})\n{self.snippet}"


def search_duckduckgo(
    query: str,
    max_results: int = 8,
    region: str = "wt-wt",
    time_filter: Optional[str] = None,
) -> List[SearchResult]:
    """
    Search the web using DuckDuckGo (completely free, no API key).

    Args:
        query: Search query string
        max_results: Maximum number of results to return
        region: Region code (wt-wt = worldwide)
        time_filter: Time filter ('d' = day, 'w' = week, 'm' = month, 'y' = year)

    Returns:
        List of SearchResult objects
    """
    _rate_limit()

    for attempt in range(3):
        try:
            from ddgs import DDGS

            results = []
            ddgs = DDGS()
            kwargs = {
                "max_results": max_results,
                "region": region,
            }
            if time_filter:
                kwargs["timelimit"] = time_filter

            for r in ddgs.text(query, **kwargs):
                results.append(SearchResult(
                    title=r.get("title", ""),
                    url=r.get("href", r.get("link", "")),
                    snippet=r.get("body", r.get("snippet", "")),
                    source="duckduckgo",
                ))

            logger.info(f"DuckDuckGo: '{query[:50]}...' -> {len(results)} results")
            return results

        except Exception as e:
            error_str = str(e)
            if "Ratelimit" in error_str or "403" in error_str:
                wait = (attempt + 1) * 3
                logger.warning(f"DuckDuckGo rate limited, retry {attempt+1}/3 in {wait}s")
                time.sleep(wait)
                continue
            logger.warning(f"DuckDuckGo search failed for '{query[:50]}': {e}")
            return []

    logger.warning(f"DuckDuckGo search exhausted retries for '{query[:50]}'")
    return []


def search_duckduckgo_news(
    query: str,
    max_results: int = 5,
    time_filter: Optional[str] = None,
) -> List[SearchResult]:
    """
    Search DuckDuckGo News (free).

    Args:
        query: Search query
        max_results: Max results
        time_filter: 'd' = day, 'w' = week, 'm' = month

    Returns:
        List of SearchResult
    """
    _rate_limit()

    for attempt in range(2):
        try:
            from ddgs import DDGS

            results = []
            ddgs = DDGS()
            kwargs = {
                "max_results": max_results,
            }
            if time_filter:
                kwargs["timelimit"] = time_filter

            for r in ddgs.news(query, **kwargs):
                results.append(SearchResult(
                    title=r.get("title", ""),
                    url=r.get("url", r.get("link", "")),
                    snippet=r.get("body", r.get("excerpt", "")),
                    source="duckduckgo_news",
                ))

            logger.info(f"DDG News: '{query[:50]}...' -> {len(results)} results")
            return results

        except Exception as e:
            error_str = str(e)
            if "Ratelimit" in error_str or "403" in error_str:
                wait = (attempt + 1) * 3
                logger.warning(f"DDG News rate limited, retry {attempt+1}/2 in {wait}s")
                time.sleep(wait)
                continue
            logger.warning(f"DDG News search failed for '{query[:50]}': {e}")
            return []

    logger.warning(f"DDG News exhausted retries for '{query[:50]}'")
    return []


def multi_search(
    query: str,
    max_results_per_engine: int = 5,
    include_news: bool = True,
    time_filter: Optional[str] = None,
) -> List[SearchResult]:
    """
    Search across multiple engines and deduplicate results.

    Args:
        query: Search query
        max_results_per_engine: Max results per engine
        include_news: Whether to include news search
        time_filter: Time filter

    Returns:
        Deduplicated list of SearchResult
    """
    all_results = []
    seen_urls = set()

    # DuckDuckGo web search
    web_results = search_duckduckgo(
        query, max_results=max_results_per_engine, time_filter=time_filter
    )
    for r in web_results:
        if r.url not in seen_urls:
            seen_urls.add(r.url)
            all_results.append(r)

    # DuckDuckGo news (skip if web search already got enough results)
    if include_news and len(all_results) < max_results_per_engine:
        news_results = search_duckduckgo_news(
            query, max_results=max_results_per_engine, time_filter=time_filter
        )
        for r in news_results:
            if r.url not in seen_urls:
                seen_urls.add(r.url)
                all_results.append(r)

    logger.info(
        f"Multi-search: '{query[:50]}...' -> {len(all_results)} total unique results"
    )
    return all_results
