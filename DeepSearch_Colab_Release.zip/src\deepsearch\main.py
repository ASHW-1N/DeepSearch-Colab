"""
Deep Search Agent Swarm — Main Entry Point (v2 — Dynamic Agents + Event Emitter)

Runs the multi-agent research pipeline and emits structured progress events
so the UI can show real-time agent thinking, progress bars, and step tracking.
"""

import os
import sys
import time
import argparse
import logging
import threading
from datetime import datetime
from typing import Optional, Callable, Any

# Force UTF-8 encoding for Windows terminal
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

from .config import Config
from .llm_client import LLMClient
from .tools.knowledge_base import KnowledgeBase
from .agents.orchestrator import OrchestratorAgent
from .agents.searcher import SearcherAgent
from .agents.analyzer import AnalyzerAgent
from .agents.reporter import ReporterAgent


def setup_logging(level: str = "INFO"):
    """Configure logging."""
    log_level = getattr(logging, level.upper(), logging.INFO)
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s | %(name)-30s | %(levelname)-7s | %(message)s",
        datefmt="%H:%M:%S",
    )
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("openai").setLevel(logging.WARNING)


def _default_event_handler(**kwargs):
    """Default event handler (prints to terminal)."""
    phase = kwargs.get("phase", "")
    agent = kwargs.get("agent", "")
    thought = kwargs.get("thought", "")
    progress = kwargs.get("progress", -1)
    print(f"  [{phase}] {agent}: {thought}" + (f" ({progress}%)" if progress >= 0 else ""))


def run_deep_search(
    query: str,
    max_rounds: int = None,
    num_searchers: int = 2,
    log_level: str = "INFO",
    on_event: Optional[Callable] = None,
    reporter_prompt_template: Optional[Any] = None,
) -> str:
    """
    Run a complete deep search with structured event emission.

    The on_event callback receives keyword arguments:
      phase: str (planning, searching, analyzing, reporting, complete)
      agent: str (agent name)
      thought: str (what the agent is thinking/doing)
      progress: int (0-100, or -1 for indeterminate)
      data: dict (optional extra data like agent specs, report content)
    """
    setup_logging(log_level)
    logger = logging.getLogger("deepsearch.main")
    emit = on_event or _default_event_handler

    # Validate config
    Config.validate()

    if max_rounds:
        Config.MAX_SEARCH_ROUNDS = max_rounds

    # Initialize
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.path.join(Config.OUTPUT_DIR, timestamp)
    os.makedirs(output_dir, exist_ok=True)

    llm = LLMClient()
    kb = KnowledgeBase(output_dir, query)

    emit(phase="planning", agent="System", thought="Initializing research pipeline...", progress=2)

    # ── Phase 1: Dynamic Agent Planning ──
    orchestrator = OrchestratorAgent(llm, kb, on_event=emit)
    agent_specs = orchestrator.plan_agents(query)

    total_agents = len(agent_specs)
    total_steps = total_agents + 2  # agents + analysis + report
    completed_steps = 0

    # ── Phase 2: Parallel Search Loop ──
    MAX_CONCURRENT_AGENTS = 5  # Throttle to protect vLLM backend

    search_round = 0
    while True:
        search_round += 1

        # Build the list of agents that still have work to do
        agents_with_work = []
        for spec in agent_specs:
            unsearched = [q for q in spec.queries if not kb.was_query_searched(q)]
            if unsearched:
                agents_with_work.append((spec, unsearched))

        if not agents_with_work:
            break

        # Define the worker function for each agent
        def run_agent(args):
            spec, unsearched = args
            idx = agent_specs.index(spec)
            agent_progress = int(15 + (idx / total_agents) * 55)

            emit(phase="searching", agent=spec.name,
                 thought=f"Starting research: {spec.role} ({spec.focus})",
                 progress=agent_progress,
                 data={"agent_id": spec.id, "role": spec.role, "round": search_round})

            searcher = SearcherAgent(
                agent_id=spec.id,
                llm_client=llm,
                knowledge_base=kb,
                original_query=query,
                role_name=spec.name,
                role_description=spec.role,
                role_focus=spec.focus,
                on_event=emit,
            )

            new_findings = searcher.search(unsearched)

            emit(phase="searching", agent=spec.name,
                 thought=f"Completed — found {new_findings} verified facts",
                 progress=int(15 + ((idx + 1) / total_agents) * 55),
                 data={"findings": new_findings, "agent_id": spec.id})

            return spec.name, new_findings

        # Launch all agents in parallel with a thread pool
        import concurrent.futures

        emit(phase="searching", agent="System",
             thought=f"Launching {len(agents_with_work)} agents in parallel (max {MAX_CONCURRENT_AGENTS} concurrent)...",
             progress=15)

        with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_CONCURRENT_AGENTS) as executor:
            futures = {executor.submit(run_agent, args): args[0].name for args in agents_with_work}
            for future in concurrent.futures.as_completed(futures):
                agent_name = futures[future]
                try:
                    name, findings = future.result()
                    logger.info(f"Agent '{name}' completed with {findings} findings")
                except Exception as e:
                    logger.error(f"Agent '{agent_name}' failed: {e}")
                    emit(phase="searching", agent=agent_name,
                         thought=f"Error: {str(e)[:80]}",
                         progress=-1)

        # Gap analysis
        if search_round < Config.MAX_SEARCH_ROUNDS:
            gap_result = orchestrator.analyze_gaps(query)
            if not gap_result.get("should_continue", False):
                break
            # Add new queries to existing agent specs
            new_qs = gap_result.get("new_sub_questions", [])
            if new_qs and agent_specs:
                for i, q in enumerate(new_qs):
                    agent_specs[i % len(agent_specs)].queries.append(q)
                all_q = kb.get_sub_questions() + new_qs
                kb.set_sub_questions(all_q)
        else:
            break

    # ── Phase 3: Analysis ──
    emit(phase="analyzing", agent="Analyzer",
         thought="Cross-referencing all findings and checking for contradictions...",
         progress=75)

    analyzer = AnalyzerAgent(llm, kb, query)
    analyzer.analyze()

    emit(phase="analyzing", agent="Analyzer",
         thought=f"Quality: {analyzer.overall_quality}/10 | Contradictions: {len(analyzer.contradictions)} | Gaps: {len(analyzer.gaps)}",
         progress=85)

    # ── Phase 4: Report Generation ──
    emit(phase="reporting", agent="Reporter",
         thought="Synthesizing all findings into a comprehensive report...",
         progress=88)

    reporter = ReporterAgent(llm, kb, query)
    report = reporter.generate_report(
        contradictions=analyzer.get_contradictions_text(),
        gaps=analyzer.get_gaps_text(),
        search_rounds=search_round,
        prompt_template=reporter_prompt_template,
    )

    report_path = reporter.save_report(report)
    kb.save()

    # Stats
    stats = kb.get_stats()
    elapsed = stats["elapsed_seconds"]
    time_str = f"{elapsed / 60:.1f} minutes" if elapsed > 60 else f"{elapsed:.0f} seconds"

    emit(phase="complete", agent="System",
         thought=f"Research complete in {time_str}",
         progress=100,
         data={
             "report": report,
             "report_path": report_path,
             "findings": stats["total_findings"],
             "sources": stats["unique_sources"],
             "searches": stats["searches_performed"],
             "time": time_str,
             "llm_requests": llm.stats["total_requests"],
             "tokens": llm.stats["total_tokens_used"],
         })

    return report_path


def main():
    parser = argparse.ArgumentParser(
        description="Deep Search Agent Swarm — Multi-agent deep research system",
    )
    parser.add_argument("query", nargs="?", help="Research query")
    parser.add_argument("--query", "-q", dest="query_flag", help="Research query (alt)")
    parser.add_argument("--rounds", "-r", type=int, default=None)
    parser.add_argument("--searchers", "-s", type=int, default=2)
    parser.add_argument("--verbose", "-v", action="store_true")

    args = parser.parse_args()
    query = args.query or args.query_flag
    if not query:
        parser.print_help()
        print("\nError: Please provide a research query!")
        sys.exit(1)

    try:
        run_deep_search(
            query=query,
            max_rounds=args.rounds,
            num_searchers=args.searchers,
            log_level="DEBUG" if args.verbose else "INFO",
        )
    except KeyboardInterrupt:
        print("\nSearch interrupted.")
    except Exception as e:
        print(f"\nError: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
