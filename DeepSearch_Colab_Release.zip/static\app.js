/* ═══════════════════════════════════════════════════════════
   DeepSearch AI — Chat Interface Logic v2
   Swarm activity in sidebar, answers centered, no emojis
   ═══════════════════════════════════════════════════════════ */

let eventSource = null;
let chatHistory = [];
let isProcessing = false;

// ── Textarea ──
const textarea = document.getElementById('chat-input');
textarea.addEventListener('input', () => {
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 150) + 'px';
});
textarea.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
});

// ── Send Button ──
document.getElementById('send-btn').addEventListener('click', () => sendMessage());

// ── Deep Search Toggle ──
const deepCheckbox = document.getElementById('deep-search-checkbox');
const toggleLabel = document.getElementById('toggle-label');
const depthSelector = document.getElementById('depth-selector');

deepCheckbox.addEventListener('change', () => {
    if (deepCheckbox.checked) {
        toggleLabel.textContent = 'Deep';
        toggleLabel.classList.add('active');
        depthSelector.classList.remove('hidden');
    } else {
        toggleLabel.textContent = 'Quick';
        toggleLabel.classList.remove('active');
        depthSelector.classList.add('hidden');
    }
});

// ── New Chat ──
document.getElementById('new-chat-btn').addEventListener('click', () => {
    chatHistory = [];
    document.getElementById('chat-messages').innerHTML = `
        <div class="welcome-screen" id="welcome-screen">
            <div class="welcome-logo">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
                    <path d="M11 8v6M8 11h6" opacity="0.4"/>
                </svg>
            </div>
            <h1 class="welcome-title">DeepSearch AI</h1>
            <p class="welcome-sub">Multi-Agent Research Swarm</p>
        </div>`;
    resetSwarmPanel();
    isProcessing = false;
    updateStatus('Ready', true);
});

// ── Send Message ──
async function sendMessage() {
    const query = textarea.value.trim();
    if (!query || isProcessing) return;

    isProcessing = true;
    const isDeep = deepCheckbox.checked;
    const rounds = parseInt(document.getElementById('search-rounds').value);

    // Remove welcome screen
    const welcome = document.getElementById('welcome-screen');
    if (welcome) welcome.remove();

    // Add user message
    addUserMessage(query);
    chatHistory.push({ role: 'user', content: query });

    // Clear input
    textarea.value = '';
    textarea.style.height = 'auto';
    document.getElementById('send-btn').disabled = true;
    updateStatus('Processing...', true);

    if (isDeep) {
        await startDeepSearch(query, rounds);
    } else {
        await startQuickChat(query);
    }
}

// ── Quick Chat ──
async function startQuickChat(query) {
    const msgId = addAIMessage();
    showThinking(msgId);

    try {
        const resp = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ messages: chatHistory, is_deep_search: false })
        });
        const data = await resp.json();
        hideThinking(msgId);
        setAIContent(msgId, data.response || 'Unable to generate a response.');
        chatHistory.push({ role: 'assistant', content: data.response });
    } catch (err) {
        hideThinking(msgId);
        setAIContent(msgId, 'Error: ' + err.message);
    }
    finishProcessing();
}

// ── Deep Search ──
async function startDeepSearch(query, rounds) {
    const msgId = addAIMessage();
    showThinking(msgId);
    activateSwarmPanel();

    if (eventSource) eventSource.close();
    eventSource = new EventSource('/stream');
    eventSource.onmessage = function(e) {
        const evt = JSON.parse(e.data);
        handleSwarmEvent(msgId, evt);
    };
    eventSource.onerror = function() { eventSource.close(); };

    try {
        await fetch('/api/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query, rounds })
        });
    } catch (err) {
        hideThinking(msgId);
        setAIContent(msgId, 'Failed to start deep search: ' + err.message);
        finishProcessing();
    }
}

function handleSwarmEvent(msgId, evt) {
    const { phase, agent, thought, progress, data } = evt;

    // Update sidebar progress
    if (progress >= 0) {
        document.getElementById('swarm-progress-fill').style.width = progress + '%';
    }
    if (thought) {
        document.getElementById('swarm-progress-label').textContent = thought.slice(0, 60);
    }

    // Update swarm status
    if (phase === 'planning') {
        document.getElementById('swarm-status').textContent = 'Planning';
    } else if (phase === 'searching') {
        document.getElementById('swarm-status').textContent = 'Searching';
    } else if (phase === 'analyzing') {
        document.getElementById('swarm-status').textContent = 'Analyzing';
    } else if (phase === 'reporting') {
        document.getElementById('swarm-status').textContent = 'Writing';
    }

    // Create agent cards in sidebar
    if (phase === 'planning' && data && data.agents) {
        renderAgentCards(data.agents);
    }

    // Update agent card status
    if (phase === 'searching' && agent && agent !== 'System') {
        updateAgentCard(agent, thought, data);
    }

    // Complete
    if (phase === 'complete' && data && data.report) {
        hideThinking(msgId);
        document.getElementById('swarm-status').textContent = 'Complete';
        document.getElementById('swarm-progress-fill').style.width = '100%';
        document.getElementById('swarm-progress-label').textContent = 'Research complete';

        const reportHtml = marked.parse(data.report);
        const statsHtml = buildStatsBar(data);
        const el = document.getElementById(msgId + '-content');
        if (el) el.innerHTML = reportHtml + statsHtml;

        chatHistory.push({ role: 'assistant', content: data.report });
        if (eventSource) eventSource.close();
        finishProcessing();
    }

    // Error
    if (phase === 'error') {
        hideThinking(msgId);
        setAIContent(msgId, 'Error: ' + thought);
        document.getElementById('swarm-status').textContent = 'Error';
        if (eventSource) eventSource.close();
        finishProcessing();
    }
}

function buildStatsBar(data) {
    return `
        <div class="stats-bar">
            <div class="stat-item"><span class="stat-label">Facts:</span><span class="stat-value">${data.findings || 0}</span></div>
            <div class="stat-item"><span class="stat-label">Sources:</span><span class="stat-value">${data.sources || 0}</span></div>
            <div class="stat-item"><span class="stat-label">Time:</span><span class="stat-value">${data.time || '-'}</span></div>
            <div class="stat-item"><span class="stat-label">LLM Calls:</span><span class="stat-value">${data.llm_requests || 0}</span></div>
            <div class="stat-item"><span class="stat-label">Tokens:</span><span class="stat-value">${(data.tokens || 0).toLocaleString()}</span></div>
        </div>`;
}

// ── Swarm Panel ──

function activateSwarmPanel() {
    document.getElementById('swarm-idle').classList.add('hidden');
    document.getElementById('swarm-active').classList.remove('hidden');
    document.getElementById('swarm-status').textContent = 'Initializing';
    document.getElementById('swarm-progress-fill').style.width = '0%';
    document.getElementById('swarm-progress-label').textContent = 'Starting...';
    document.getElementById('agent-grid').innerHTML = '';
}

function resetSwarmPanel() {
    document.getElementById('swarm-idle').classList.remove('hidden');
    document.getElementById('swarm-active').classList.add('hidden');
    document.getElementById('agent-grid').innerHTML = '';
}

function renderAgentCards(agents) {
    const grid = document.getElementById('agent-grid');
    grid.innerHTML = agents.map(a => `
        <div class="agent-card" id="ac-${slugify(a.name)}">
            <div class="agent-card-header">
                <span class="agent-name">${escapeHtml(a.name)}</span>
                <span class="agent-badge">Queued</span>
            </div>
            <div class="agent-status">Waiting...</div>
        </div>
    `).join('');
}

function updateAgentCard(agentName, thought, data) {
    const card = document.getElementById('ac-' + slugify(agentName));
    if (!card) return;

    const badge = card.querySelector('.agent-badge');
    const status = card.querySelector('.agent-status');

    if (thought && thought.toLowerCase().includes('completed')) {
        card.className = 'agent-card done';
        const findings = data && data.findings !== undefined ? data.findings : '?';
        badge.textContent = findings + ' findings';
        status.textContent = 'Complete';
    } else if (thought && thought.toLowerCase().includes('error')) {
        card.className = 'agent-card error';
        badge.textContent = 'Error';
        status.textContent = thought.slice(0, 50);
    } else {
        card.className = 'agent-card active';
        badge.textContent = 'Active';
        status.textContent = thought ? thought.slice(0, 50) + (thought.length > 50 ? '...' : '') : 'Working...';
    }
}

// ── Message Helpers ──

function addUserMessage(text) {
    const container = document.getElementById('chat-messages');
    const row = document.createElement('div');
    row.className = 'message-row user';
    row.innerHTML = `
        <div class="message-label user-label">You</div>
        <div class="message-content user-content">${escapeHtml(text)}</div>
    `;
    container.appendChild(row);
    scrollToBottom();
}

function addAIMessage() {
    const container = document.getElementById('chat-messages');
    const id = 'ai-' + Date.now();
    const row = document.createElement('div');
    row.className = 'message-row ai';
    row.id = id;
    row.innerHTML = `
        <div class="message-label ai-label">DeepSearch</div>
        <div class="thinking-indicator" id="${id}-thinking">
            <div class="thinking-dots"><span></span><span></span><span></span></div>
            <span>Thinking...</span>
        </div>
        <div class="message-content" id="${id}-content"></div>
    `;
    container.appendChild(row);
    scrollToBottom();
    return id;
}

function showThinking(msgId) {
    const el = document.getElementById(msgId + '-thinking');
    if (el) el.style.display = 'flex';
}

function hideThinking(msgId) {
    const el = document.getElementById(msgId + '-thinking');
    if (el) el.style.display = 'none';
}

function setAIContent(msgId, markdown) {
    const el = document.getElementById(msgId + '-content');
    if (el) el.innerHTML = marked.parse(markdown);
    scrollToBottom();
}

// ── Utilities ──

function scrollToBottom() {
    const container = document.getElementById('chat-messages');
    requestAnimationFrame(() => {
        container.scrollTop = container.scrollHeight;
    });
}

function finishProcessing() {
    isProcessing = false;
    document.getElementById('send-btn').disabled = false;
    updateStatus('Ready', true);
}

function updateStatus(text, online) {
    document.getElementById('status-text').textContent = text;
    document.getElementById('status-dot').style.background = online ? 'var(--green)' : 'var(--amber)';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function slugify(name) {
    return name.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
}
