"""
Deep Search Agent Swarm — LLM Client
Wraps OpenAI-compatible APIs (OpenRouter, vLLM, Groq) with rate limiting
and retry logic. Adapted from MiroFish's LLMClient pattern.
"""

import json
import re
import time
import threading
from typing import Optional, Dict, Any, List

from openai import OpenAI

from .config import Config


class RateLimiter:
    """
    Token-bucket rate limiter for Groq API.
    Thread-safe — used by all agents concurrently.
    """

    def __init__(self, max_requests_per_minute: int = 30):
        self.max_rpm = max_requests_per_minute
        self.interval = 60.0 / max_requests_per_minute  # seconds between requests
        self.lock = threading.Lock()
        self.last_request_time = 0.0

    def wait(self):
        """Block until it's safe to make another request."""
        with self.lock:
            now = time.time()
            elapsed = now - self.last_request_time
            if elapsed < self.interval:
                sleep_time = self.interval - elapsed
                time.sleep(sleep_time)
            self.last_request_time = time.time()


# Global rate limiter shared by all LLM clients
_rate_limiter = RateLimiter(max_requests_per_minute=Config.MAX_REQUESTS_PER_MINUTE)


class LLMClient:
    """
    LLM client for Groq API.

    Features:
    - OpenAI SDK compatibility (Groq uses the same format)
    - Dual-model routing: big model for reasoning, small for extraction
    - Automatic rate limiting with token bucket
    - Exponential backoff on 429 errors
    - JSON response parsing with cleanup
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: Optional[str] = None,
    ):
        self.api_key = api_key or Config.GROQ_API_KEY
        self.base_url = base_url or Config.GROQ_BASE_URL
        self.default_model = model or Config.BIG_MODEL

        if not self.api_key:
            raise ValueError(
                "GROQ_API_KEY not configured. "
                "Get a free key at https://console.groq.com"
            )

        self.client = OpenAI(
            api_key=self.api_key,
            base_url=self.base_url,
        )

        # Stats
        self._total_requests = 0
        self._total_tokens_used = 0
        self._lock = threading.Lock()

    @property
    def stats(self) -> Dict[str, int]:
        return {
            "total_requests": self._total_requests,
            "total_tokens_used": self._total_tokens_used,
        }

    def chat(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        response_format: Optional[Dict] = None,
    ) -> str:
        """
        Send a chat completion request to Groq.

        Args:
            messages: Conversation messages
            model: Model override (defaults to self.default_model)
            temperature: Sampling temperature
            max_tokens: Max tokens in response
            response_format: Optional response format (e.g. JSON mode)

        Returns:
            Model response text
        """
        model = model or self.default_model

        kwargs = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
        }

        # vLLM uses standard max_tokens; Qwen on Groq/OpenRouter needs max_completion_tokens
        if Config.LLM_BACKEND == "colab":
            kwargs["max_tokens"] = max_tokens
        elif "qwen" in model.lower():
            kwargs["max_completion_tokens"] = max_tokens
        else:
            kwargs["max_tokens"] = max_tokens

        if response_format:
            # vLLM may not support json_object; only add if not colab backend
            if Config.LLM_BACKEND == "colab":
                # Skip response_format for vLLM — we parse JSON from raw output
                pass
            else:
                kwargs["response_format"] = response_format

        # Retry with exponential backoff
        last_error = None
        delay = Config.RETRY_BASE_DELAY

        for attempt in range(Config.RETRY_MAX_ATTEMPTS):
            try:
                # Rate limit
                _rate_limiter.wait()

                response = self.client.chat.completions.create(**kwargs)
                content = response.choices[0].message.content or ""

                # Strip Qwen 3's <think> reasoning tags
                # Handle both complete and incomplete (truncated) think blocks
                content = re.sub(r'<think>[\s\S]*?</think>', '', content)
                # Handle truncated think blocks (no closing tag)
                content = re.sub(r'<think>[\s\S]*$', '', content)
                content = content.strip()

                # Track stats
                with self._lock:
                    self._total_requests += 1
                    if response.usage:
                        self._total_tokens_used += response.usage.total_tokens

                return content

            except Exception as e:
                last_error = e
                error_str = str(e)

                # Rate limit hit — back off
                if "429" in error_str or "rate" in error_str.lower():
                    wait_time = delay * (2 ** attempt)
                    time.sleep(wait_time)
                    continue

                # Other errors — retry with shorter delay
                if attempt < Config.RETRY_MAX_ATTEMPTS - 1:
                    time.sleep(delay)
                    continue

                raise

        raise last_error

    def chat_json(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 4096,
    ) -> Dict[str, Any]:
        """
        Send a chat request and parse the response as JSON.

        Args:
            messages: Conversation messages
            model: Model override
            temperature: Sampling temperature
            max_tokens: Max tokens

        Returns:
            Parsed JSON dictionary
        """
        response = self.chat(
            messages=messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            response_format={"type": "json_object"},
        )

        # Clean markdown code block markers
        cleaned = response.strip()
        cleaned = re.sub(r'^```(?:json)?\s*\n?', '', cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r'\n?```\s*$', '', cleaned)
        cleaned = cleaned.strip()

        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            # Try to extract JSON from the response
            json_match = re.search(r'\{[\s\S]*\}', cleaned)
            if json_match:
                try:
                    return json.loads(json_match.group())
                except json.JSONDecodeError:
                    pass
            raise ValueError(f"LLM returned invalid JSON: {cleaned[:200]}...")

    def chat_small(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 2048,
    ) -> str:
        """Use the small/fast model for simple tasks."""
        return self.chat(
            messages=messages,
            model=Config.SMALL_MODEL,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    def chat_small_json(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.2,
        max_tokens: int = 2048,
    ) -> Dict[str, Any]:
        """Use the small/fast model and parse JSON response."""
        return self.chat_json(
            messages=messages,
            model=Config.SMALL_MODEL,
            temperature=temperature,
            max_tokens=max_tokens,
        )
