"""
Deep Search Agent Swarm — Social Media Search Tool
Scrapes live Reddit threads and Twitter/X posts using Scrapling + DuckDuckGo.
Uses DuckDuckGo site-specific searches to find relevant social media discussions,
then Scrapling's StealthyFetcher to extract the actual content.
"""

import logging
import re
from typing import List, Optional
from dataclasses import dataclass, field

logger = logging.getLogger("deepsearch.tools.social_search")


@dataclass
class SocialPost:
    """Represents a single social media post/comment."""
    platform: str          # "reddit", "twitter", "forum"
    title: str = ""
    content: str = ""
    author: str = ""
    url: str = ""
    score: str = ""        # upvotes, likes, etc.
    subreddit: str = ""    # Reddit-specific
    timestamp: str = ""


@dataclass
class SocialSearchResult:
    """Result from a social media search."""
    success: bool = False
    posts: List[SocialPost] = field(default_factory=list)
    error: str = ""
    platform: str = ""
    query: str = ""


def search_reddit(query: str, max_results: int = 5) -> SocialSearchResult:
    """
    Search Reddit for discussions related to the query.
    Uses DuckDuckGo with site:reddit.com to find threads,
    then Scrapling to extract the actual content.
    """
    result = SocialSearchResult(platform="reddit", query=query)

    try:
        from duckduckgo_search import DDGS

        # Search Reddit via DuckDuckGo
        search_query = f"site:reddit.com {query}"
        logger.info(f"Searching Reddit via DuckDuckGo: {search_query[:60]}...")

        with DDGS() as ddgs:
            raw_results = list(ddgs.text(search_query, max_results=max_results))

        if not raw_results:
            result.error = "No Reddit results found"
            return result

        posts = []
        for r in raw_results:
            url = r.get("href", "")
            title = r.get("title", "")
            snippet = r.get("body", "")

            # Extract subreddit from URL
            subreddit = ""
            sr_match = re.search(r'reddit\.com/r/(\w+)', url)
            if sr_match:
                subreddit = f"r/{sr_match.group(1)}"

            # Try to fetch full content with Scrapling
            full_content = _fetch_social_content(url)

            post = SocialPost(
                platform="reddit",
                title=title,
                content=full_content or snippet,
                url=url,
                subreddit=subreddit,
            )
            posts.append(post)

        result.posts = posts
        result.success = True
        logger.info(f"Found {len(posts)} Reddit discussions")

    except Exception as e:
        result.error = f"Reddit search failed: {str(e)}"
        logger.warning(result.error)

    return result


def search_twitter(query: str, max_results: int = 5) -> SocialSearchResult:
    """
    Search Twitter/X for posts related to the query.
    Uses DuckDuckGo with site:twitter.com OR site:x.com.
    """
    result = SocialSearchResult(platform="twitter", query=query)

    try:
        from duckduckgo_search import DDGS

        search_query = f"(site:twitter.com OR site:x.com) {query}"
        logger.info(f"Searching Twitter/X via DuckDuckGo: {search_query[:60]}...")

        with DDGS() as ddgs:
            raw_results = list(ddgs.text(search_query, max_results=max_results))

        if not raw_results:
            result.error = "No Twitter/X results found"
            return result

        posts = []
        for r in raw_results:
            url = r.get("href", "")
            title = r.get("title", "")
            snippet = r.get("body", "")

            # Extract author from URL or title
            author = ""
            author_match = re.search(r'(?:twitter|x)\.com/(\w+)', url)
            if author_match:
                author = f"@{author_match.group(1)}"

            post = SocialPost(
                platform="twitter",
                title=title,
                content=snippet,  # Twitter is hard to scrape fully, snippet is usually enough
                author=author,
                url=url,
            )
            posts.append(post)

        result.posts = posts
        result.success = True
        logger.info(f"Found {len(posts)} Twitter/X posts")

    except Exception as e:
        result.error = f"Twitter search failed: {str(e)}"
        logger.warning(result.error)

    return result


def search_forums(query: str, max_results: int = 5) -> SocialSearchResult:
    """
    Search community forums (Quora, StackExchange, HackerNews, etc.)
    for discussions related to the query.
    """
    result = SocialSearchResult(platform="forum", query=query)

    try:
        from duckduckgo_search import DDGS

        search_query = f"(site:quora.com OR site:news.ycombinator.com OR site:stackexchange.com OR site:medium.com) {query}"
        logger.info(f"Searching forums: {search_query[:60]}...")

        with DDGS() as ddgs:
            raw_results = list(ddgs.text(search_query, max_results=max_results))

        if not raw_results:
            result.error = "No forum results found"
            return result

        posts = []
        for r in raw_results:
            url = r.get("href", "")
            title = r.get("title", "")
            snippet = r.get("body", "")

            # Determine platform from URL
            platform = "forum"
            if "quora.com" in url:
                platform = "quora"
            elif "ycombinator" in url:
                platform = "hackernews"
            elif "stackexchange" in url or "stackoverflow" in url:
                platform = "stackexchange"
            elif "medium.com" in url:
                platform = "medium"

            # Try to fetch full content
            full_content = _fetch_social_content(url)

            post = SocialPost(
                platform=platform,
                title=title,
                content=full_content or snippet,
                url=url,
            )
            posts.append(post)

        result.posts = posts
        result.success = True
        logger.info(f"Found {len(posts)} forum discussions")

    except Exception as e:
        result.error = f"Forum search failed: {str(e)}"
        logger.warning(result.error)

    return result


def search_social(query: str, platforms: List[str] = None, max_per_platform: int = 3) -> str:
    """
    Main entry point: Search across multiple social platforms.
    Returns a formatted string ready for the agent to consume.

    Args:
        query: The search query
        platforms: List of platforms to search ("reddit", "twitter", "forums")
        max_per_platform: Maximum results per platform
    """
    if platforms is None:
        platforms = ["reddit", "forums"]  # Default: Reddit + forums (Twitter is flaky)

    all_posts = []

    for platform in platforms:
        if platform == "reddit":
            result = search_reddit(query, max_results=max_per_platform)
        elif platform == "twitter":
            result = search_twitter(query, max_results=max_per_platform)
        elif platform == "forums":
            result = search_forums(query, max_results=max_per_platform)
        else:
            continue

        if result.success:
            all_posts.extend(result.posts)

    if not all_posts:
        return f"No social media discussions found for: '{query}'"

    # Format output for the agent
    output = f"Found {len(all_posts)} social media discussions for '{query}':\n\n"
    for i, post in enumerate(all_posts, 1):
        platform_label = post.platform.upper()
        if post.subreddit:
            platform_label = f"REDDIT ({post.subreddit})"
        elif post.author:
            platform_label = f"{post.platform.upper()} ({post.author})"

        output += f"{i}. **[{platform_label}]** {post.title}\n"
        output += f"   URL: {post.url}\n"
        # Truncate content to keep things manageable
        content_preview = post.content[:500] if post.content else "(no content extracted)"
        output += f"   Content: {content_preview}\n\n"

    return output


def _fetch_social_content(url: str, max_chars: int = 2000) -> Optional[str]:
    """
    Attempt to fetch full content from a social media URL using Scrapling.
    Falls back gracefully if Scrapling is unavailable.
    """
    try:
        from scrapling.fetchers import StealthyFetcher

        page = StealthyFetcher.fetch(url, headless=True)
        if page:
            # Try trafilatura first for clean text
            try:
                import trafilatura
                html = str(page)
                text = trafilatura.extract(html, include_comments=True)
                if text:
                    return text[:max_chars]
            except Exception:
                pass

            # Fallback to raw text
            if hasattr(page, 'text') and page.text:
                return page.text[:max_chars]

    except Exception as e:
        logger.debug(f"Scrapling fetch failed for {url[:50]}: {e}")

    return None
