"""
Deep Search Agent Swarm — FastAPI Backend (v3 — Chat Interface)
Supports both Quick Chat (direct LLM) and Deep Search (swarm mode).
"""

import os
import sys
import json
import asyncio
import logging
import threading
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import List, Optional

from .main import run_deep_search
from .config import Config
from .llm_client import LLMClient

app = FastAPI(title="Deep Search AI")

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
STATIC_DIR = os.path.join(PROJECT_ROOT, "static")
TEMPLATES_DIR = os.path.join(PROJECT_ROOT, "templates")

os.makedirs(STATIC_DIR, exist_ok=True)
os.makedirs(TEMPLATES_DIR, exist_ok=True)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
templates = Jinja2Templates(directory=TEMPLATES_DIR)

# SSE queue for structured events
event_queue: asyncio.Queue = None
main_loop: asyncio.AbstractEventLoop = None

logger = logging.getLogger("deepsearch.app")


@app.on_event("startup")
async def on_startup():
    """Capture the main event loop and create the queue at startup."""
    global event_queue, main_loop
    main_loop = asyncio.get_running_loop()
    event_queue = asyncio.Queue()


# ── Request Models ──

class ChatMessage(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: List[ChatMessage]
    is_deep_search: bool = False

class SearchRequest(BaseModel):
    query: str
    rounds: int = 2


# ── Routes ──

@app.get("/", response_class=HTMLResponse)
async def get_ui(request: Request):
    return templates.TemplateResponse(name="index.html", request=request)


@app.post("/api/chat")
async def quick_chat(req: ChatRequest):
    """
    Quick Chat mode: Send the conversation history directly to the LLM
    without triggering the agent swarm. Returns a fast conversational response.
    """
    try:
        llm = LLMClient()

        # Build messages for the LLM
        system_msg = {
            "role": "system",
            "content": (
                "You are DeepSearch AI, a helpful and knowledgeable research assistant. "
                "Answer the user's questions directly, clearly, and conversationally. "
                "If you don't know something, say so honestly. "
                "Use markdown formatting for clarity: headers, bullet points, bold text, etc. "
                "Keep responses informative but concise."
            )
        }

        messages = [system_msg]
        for m in req.messages:
            messages.append({"role": m.role, "content": m.content})

        response = llm.chat(
            messages=messages,
            model=Config.BIG_MODEL,
            temperature=0.7,
            max_tokens=2048,
        )

        return {"response": response}

    except Exception as e:
        logger.error(f"Quick chat failed: {e}")
        return {"response": f"I encountered an error: {str(e)}. Please check that your LLM backend is running."}


@app.get("/stream")
async def sse_stream():
    """Server-Sent Events endpoint streaming structured progress events."""
    async def generator():
        while True:
            event = await event_queue.get()
            yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"

    return StreamingResponse(generator(), media_type="text/event-stream")


@app.post("/api/search")
async def start_search(req: SearchRequest):
    """Run deep search in a background thread with structured event emission."""

    # Capture the loop reference from the main thread BEFORE entering the worker
    loop = main_loop

    def emit_event(**kwargs):
        """Thread-safe: push events into the main loop's queue from any thread."""
        event = {
            "phase": kwargs.get("phase", ""),
            "agent": kwargs.get("agent", ""),
            "thought": kwargs.get("thought", ""),
            "progress": kwargs.get("progress", -1),
        }
        data = kwargs.get("data", {})
        if data:
            event["data"] = data

        # Use the captured main loop to safely enqueue from the worker thread
        loop.call_soon_threadsafe(event_queue.put_nowait, event)

    def search_worker():
        try:
            run_deep_search(
                query=req.query,
                max_rounds=req.rounds,
                num_searchers=2,
                on_event=emit_event,
            )
        except Exception as e:
            logging.getLogger("deepsearch").error(f"Pipeline failed: {e}")
            emit_event(phase="error", agent="System",
                       thought=f"Pipeline failed: {str(e)}", progress=0)

    threading.Thread(target=search_worker, daemon=True).start()

    return {"status": "started"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
