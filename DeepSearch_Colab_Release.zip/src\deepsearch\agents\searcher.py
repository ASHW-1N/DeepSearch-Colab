"""
Deep Search Agent Swarm — Searcher Agent (v2 — Dynamic Roles + Events)
Accepts a dynamic role/focus from the Orchestrator and emits structured progress events.
"""

import logging
from typing import Dict, Any, Optional, Callable
from datetime import datetime

from ..config import Config
from .base_agent import BaseAgent
from ..tools.web_search import multi_search
from ..tools.content_extractor import extract_content
from ..tools.social_search import search_social
from ..tools.knowledge_base import KnowledgeBase, Finding
from ..prompts.agent_prompts import SEARCHER_SYSTEM_PROMPT, SEARCHER_TASK_PROMPT

logger = logging.getLogger("deepsearch.agents.searcher")


class SearcherAgent(BaseAgent):
    """
    Searcher agent with a dynamically assigned role and focus.
    Each instance is a specialized persona created by the Orchestrator.
    """

    def __init__(
        self,
        agent_id: str,
        llm_client,
        knowledge_base: KnowledgeBase,
        original_query: str,
        role_name: str = "Searcher",
        role_description: str = "General web researcher",
        role_focus: str = "broad coverage",
        on_event: Optional[Callable] = None,
    ):
        super().__init__(
            agent_id=agent_id,
            llm_client=llm_client,
            max_iterations=Config.MAX_REACT_ITERATIONS,
            model=Config.SMALL_MODEL,
        )
        self.kb = knowledge_base
        self.original_query = original_query
        self.role_name = role_name
        self.role_description = role_description
        self.role_focus = role_focus
        self.on_event = on_event or (lambda **kw: None)

    def _emit(self, thought: str, **kwargs):
        self.on_event(phase="searching", agent=self.role_name, thought=thought, **kwargs)

    def search(self, sub_questions: list) -> int:
        """Search for answers to the given sub-questions."""
        if not sub_questions:
            return 0

        initial_count = self.kb.finding_count

        # Build the system prompt with dynamic role injected
        base_prompt = SEARCHER_SYSTEM_PROMPT.format(original_query=self.original_query)
        role_injection = (
            f"\n\n## YOUR SPECIALIZED ROLE\n"
            f"Name: {self.role_name}\n"
            f"Specialization: {self.role_description}\n"
            f"Focus: {self.role_focus}\n"
            f"Search from THIS specific angle. Prioritize sources relevant to your focus.\n"
        )
        system_prompt = base_prompt + role_injection

        searched_queries = [q for q in sub_questions if self.kb.was_query_searched(q)]
        extracted_urls = list(self.kb._extracted_urls)[:20]

        user_prompt = SEARCHER_TASK_PROMPT.format(
            sub_questions="\n".join(f"- {q}" for q in sub_questions),
            searched_queries=("\n".join(f"- {q}" for q in searched_queries) if searched_queries else "(none)"),
            extracted_urls=("\n".join(f"- {u}" for u in extracted_urls) if extracted_urls else "(none)"),
        )

        logger.info(f"[{self.agent_id}] Starting search with {len(sub_questions)} sub-questions")
        self._emit(f"Searching {len(sub_questions)} queries as {self.role_description}...", progress=-1)

        # Run the ReACT loop with event callbacks
        self.run_react_loop(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            on_thought=self._on_thought,
            on_tool_call=self._on_tool_call,
        )

        findings_added = self.kb.finding_count - initial_count
        logger.info(f"[{self.agent_id}] Finished: {findings_added} new findings, {self.tool_calls_made} tool calls")

        return findings_added

    def _on_thought(self, agent_id, iteration, thought_preview):
        logger.debug(f"[{agent_id}] Think #{iteration}: {thought_preview}")
        # Clean up the thought for the UI
        clean = thought_preview.strip()[:120]
        if clean:
            self._emit(f"Thinking: {clean}...", progress=-1)

    def _on_tool_call(self, agent_id, tool_name, params):
        logger.info(f"[{agent_id}] Tool: {tool_name}({list(params.keys())})")
        if tool_name == "web_search":
            q = params.get("query", "")[:60]
            self._emit(f"Searching web: \"{q}\"...", progress=-1)
        elif tool_name == "extract_content":
            url = params.get("url", "")[:50]
            self._emit(f"Reading article: {url}...", progress=-1)
        elif tool_name == "social_search":
            q = params.get("query", "")[:60]
            platforms = params.get("platforms", ["reddit", "forums"])
            self._emit(f"Searching social media ({', '.join(platforms)}): \"{q}\"...", progress=-1)
        elif tool_name == "save_finding":
            self._emit(f"Saving verified fact to knowledge base", progress=-1)

    def execute_tool(self, tool_name: str, parameters: Dict[str, Any]) -> str:
        """Execute a searcher tool."""
        if tool_name == "web_search":
            return self._tool_web_search(parameters)
        elif tool_name == "extract_content":
            return self._tool_extract_content(parameters)
        elif tool_name == "social_search":
            return self._tool_social_search(parameters)
        elif tool_name == "save_finding":
            return self._tool_save_finding(parameters)
        else:
            return f"Unknown tool: {tool_name}. Available: web_search, extract_content, social_search, save_finding"

    def _tool_web_search(self, params: Dict[str, Any]) -> str:
        query = params.get("query", "")
        if not query:
            return "Error: 'query' parameter is required"

        include_news = params.get("include_news", True)
        time_filter = params.get("time_filter", None)

        if self.kb.was_query_searched(query):
            return f"This query was already searched: '{query}'. Try a different query."

        results = multi_search(
            query=query,
            max_results_per_engine=Config.MAX_SEARCH_RESULTS_PER_QUERY,
            include_news=include_news,
            time_filter=time_filter,
        )

        self.kb.record_search(query=query, engine="multi", urls=[r.url for r in results])

        if not results:
            return f"No results found for: '{query}'"

        output = f"Found {len(results)} results for '{query}':\n\n"
        for i, r in enumerate(results, 1):
            output += f"{i}. **{r.title}**\n   URL: {r.url}\n   {r.snippet}\n\n"
        return output

    def _tool_extract_content(self, params: Dict[str, Any]) -> str:
        url = params.get("url", "")
        if not url:
            return "Error: 'url' parameter is required"

        if self.kb.was_url_extracted(url):
            return f"This URL was already extracted: {url}. Try a different URL."

        content = extract_content(url, max_chars=Config.MAX_CONTENT_LENGTH)
        self.kb.mark_url_extracted(url)

        if not content.success:
            return f"Failed to extract content from {url}: {content.error}"

        result = f"**{content.title}** ({content.word_count} words)\n"
        result += f"URL: {url}\n\n"
        result += content.truncated_text(max_chars=Config.MAX_CONTENT_LENGTH)
        return result

    def _tool_social_search(self, params: Dict[str, Any]) -> str:
        """Search social media platforms for discussions."""
        query = params.get("query", "")
        if not query:
            return "Error: 'query' parameter is required"

        platforms = params.get("platforms", ["reddit", "forums"])
        return search_social(query=query, platforms=platforms, max_per_platform=3)

    def _tool_save_finding(self, params: Dict[str, Any]) -> str:
        content = params.get("content", "")
        source_url = params.get("source_url", "")
        source_title = params.get("source_title", "")
        sub_question = params.get("sub_question", "")
        confidence = params.get("confidence", 0.6)

        if not content:
            return "Error: 'content' parameter is required"
        if not source_url:
            return "Error: 'source_url' parameter is required (anti-hallucination rule!)"

        finding = Finding(
            id=Finding.make_id(content, source_url),
            content=content,
            source_url=source_url,
            source_title=source_title or "Unknown",
            sub_question=sub_question,
            confidence=float(confidence),
            agent_id=self.agent_id,
            timestamp=datetime.now().isoformat(),
        )

        is_new = self.kb.add_finding(finding)
        if is_new:
            return f"Finding saved (ID: {finding.id}). Total findings: {self.kb.finding_count}"
        else:
            return f"Similar finding already exists (boosted confidence). Total: {self.kb.finding_count}"
