"""
DeepSearch Evaluation — Hallucination Reward Function

LLM-as-a-Judge scoring: compares the generated research report
against expected ground-truth facts and penalizes hallucinations.
Works with both OpenRouter and self-hosted vLLM backends.
"""

import json
import re
from openai import OpenAI
from deepsearch.config import Config


def evaluate_hallucination(final_report: str, expected_facts: list[str]) -> float:
    """
    LLM-as-a-Judge to score the generated report.
    It penalizes missing expected facts and punishes hallucinations.
    
    Returns:
        float: Score between 0.0 (complete hallucination) and 1.0 (perfect).
    """
    if not final_report:
        return 0.0

    # Ensure backend is resolved
    Config._resolve_backend()

    client = OpenAI(
        api_key=Config.GROQ_API_KEY,
        base_url=Config.GROQ_BASE_URL,
    )

    judge_prompt = (
        "You are a strict grading judge evaluating an AI research report.\n"
        f"Task output (The Report):\n{final_report[:8000]}\n\n"
        f"Expected facts to be present:\n{expected_facts}\n\n"
        "Instructions:\n"
        "1. Check if the report contains the expected facts.\n"
        "2. Check if the report hallucinates details outside the scope.\n"
        "3. You MUST respond with ONLY a JSON object in this exact format:\n"
        '   {"reason": "brief explanation", "score": 0.7}\n'
        "4. The score must be between 0.0 and 1.0.\n"
        "   1.0 = all facts present, no hallucinations.\n"
        "   0.0 = completely wrong or fabricated.\n"
        "Respond with ONLY the JSON object, nothing else.\n"
    )

    try:
        kwargs = {
            "model": Config.BIG_MODEL,
            "messages": [{"role": "user", "content": judge_prompt}],
            "temperature": 0.0,
            "max_tokens": 200,
        }

        response = client.chat.completions.create(**kwargs)
        content = response.choices[0].message.content or ""

        # Strip think tags (Qwen quirk)
        content = re.sub(r'<think>[\s\S]*?</think>', '', content)
        content = re.sub(r'<think>[\s\S]*$', '', content)
        content = content.strip()

        # Clean markdown wrappers
        if "```json" in content:
            content = content.replace("```json", "").replace("```", "").strip()
        if "```" in content:
            content = re.sub(r'```\s*', '', content).strip()

        # Try to extract JSON
        json_match = re.search(r'\{[\s\S]*\}', content)
        if json_match:
            result = json.loads(json_match.group())
            score = float(result.get("score", 0.0))
            reason = result.get("reason", "No reason provided")
            print(f"   [SCORE] Judge Score: {score:.2f} -- {reason}")
            return max(0.0, min(1.0, score))

        print(f"   [WARN] Could not parse judge response: {content[:100]}")
        return 0.0

    except Exception as e:
        print(f"   [ERROR] Error in grading: {e}")
        return 0.0
