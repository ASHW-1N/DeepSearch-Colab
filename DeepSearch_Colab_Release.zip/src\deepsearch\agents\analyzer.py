"""
Deep Search Agent Swarm — Analyzer Agent
Cross-references findings, validates facts, detects topic drift.
Quality control layer.
"""

import json
import logging
from typing import Dict, Any, List, Optional

from ..config import Config
from ..llm_client import LLMClient
from ..tools.knowledge_base import KnowledgeBase
from ..prompts.agent_prompts import ANALYZER_SYSTEM_PROMPT, ANALYZER_USER_PROMPT

logger = logging.getLogger("deepsearch.agents.analyzer")


class AnalyzerAgent:
    """
    The Analyzer validates research findings:
    - Checks each finding's relevance to the original query (focus score)
    - Detects contradictions between findings
    - Adjusts confidence based on source quality and corroboration
    - Identifies gaps in research

    Uses the big model (Llama 3.3 70B) for nuanced reasoning.
    """

    def __init__(self, llm: LLMClient, knowledge_base: KnowledgeBase, original_query: str):
        self.llm = llm
        self.kb = knowledge_base
        self.original_query = original_query
        self.contradictions: List[Dict[str, Any]] = []
        self.gaps: List[str] = []
        self.overall_quality: float = 0.0

    def analyze(self) -> Dict[str, Any]:
        """
        Analyze all findings in the knowledge base.

        Returns:
            Analysis results with quality scores, contradictions, gaps
        """
        findings = self.kb.get_findings()
        if not findings:
            logger.warning("No findings to analyze")
            return {
                "overall_quality": 0,
                "contradictions": [],
                "gaps": ["No findings collected yet"],
                "summary": "No research data available for analysis.",
            }

        stats = self.kb.get_stats()

        # Format findings for the LLM
        findings_text = ""
        for i, f in enumerate(findings, 1):
            findings_text += (
                f"\n--- Finding {i} (ID: {f.id}) ---\n"
                f"Content: {f.content}\n"
                f"Source: [{f.source_title}]({f.source_url})\n"
                f"Sub-question: {f.sub_question}\n"
                f"Current confidence: {f.confidence:.2f}\n"
                f"Corroborated by: {len(f.corroborated_by)} other agents\n"
            )

        system_prompt = ANALYZER_SYSTEM_PROMPT.format(
            original_query=self.original_query,
        )
        user_prompt = ANALYZER_USER_PROMPT.format(
            findings_text=findings_text,
            finding_count=stats["total_findings"],
            unique_sources=stats["unique_sources"],
            avg_confidence=stats["avg_confidence"],
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        try:
            result = self.llm.chat_json(messages=messages, temperature=0.3)
        except Exception as e:
            logger.warning(f"Analyzer LLM call failed: {e}")
            return {
                "overall_quality": 5.0,
                "contradictions": [],
                "gaps": [],
                "summary": f"Analysis could not be completed: {e}",
            }

        # Apply focus scores and confidence adjustments to the KB
        validated = result.get("validated_findings", [])
        for vf in validated:
            finding_id = vf.get("finding_id", "")
            # Find matching finding(s)
            for f in findings:
                if f.id == finding_id or finding_id in f.id:
                    if "focus_score" in vf:
                        f.focus_score = float(vf["focus_score"])
                    if "adjusted_confidence" in vf:
                        f.confidence = float(vf["adjusted_confidence"])

        # Store analysis results
        self.contradictions = result.get("contradictions", [])
        self.gaps = result.get("key_gaps", [])
        self.overall_quality = result.get("overall_quality", 5.0)

        # Remove off-topic findings (focus score too low)
        removed = 0
        for f in findings:
            if f.focus_score < Config.FOCUS_SCORE_THRESHOLD:
                logger.info(
                    f"Removing off-topic finding {f.id}: "
                    f"focus={f.focus_score}, content='{f.content[:60]}...'"
                )
                del self.kb._findings[f.id]
                removed += 1

        if removed:
            logger.info(f"Removed {removed} off-topic findings")

        # Save updated KB
        self.kb.save()

        logger.info(
            f"Analysis complete: quality={self.overall_quality}/10, "
            f"contradictions={len(self.contradictions)}, gaps={len(self.gaps)}"
        )

        return result

    def get_contradictions_text(self) -> str:
        """Format contradictions for the reporter."""
        if not self.contradictions:
            return "No contradictions found between sources."

        parts = []
        for c in self.contradictions:
            parts.append(f"- {c.get('description', 'Unknown contradiction')}")
        return "\n".join(parts)

    def get_gaps_text(self) -> str:
        """Format gaps for the reporter."""
        if not self.gaps:
            return "No significant gaps identified."

        return "\n".join(f"- {gap}" for gap in self.gaps)
