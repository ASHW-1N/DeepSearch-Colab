"""
Deep Search Agent Swarm — Configuration
Supports two backends:
  1. OpenRouter (cloud API, token limits apply)
  2. Colab/vLLM  (self-hosted, unlimited tokens)

Set LLM_BACKEND=colab in .env to use the self-hosted backend.
"""

import os
from dotenv import load_dotenv

# Project root is two levels up from src/deepsearch/config.py
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))

# Load .env from DeepSearch root directory
load_dotenv(os.path.join(PROJECT_ROOT, '.env'))


class Config:
    """Central configuration for the Deep Search system."""

    # ── Backend Selection ──
    # Set to "colab" in .env to use self-hosted vLLM on Google Colab
    # Set to "openrouter" (default) to use OpenRouter cloud API
    LLM_BACKEND: str = os.getenv("LLM_BACKEND", "openrouter")

    # ── API Connection ──
    # These are resolved dynamically based on LLM_BACKEND
    LLM_BASE_URL: str = os.getenv("LLM_BASE_URL", "")
    LLM_API_KEY: str = os.getenv("LLM_API_KEY", "")

    # ── OpenRouter fallback (used when LLM_BACKEND=openrouter) ──
    OPENROUTER_API_KEY: str = os.getenv("OPENROUTER_API_KEY", "")
    OPENROUTER_BASE_URL: str = "https://openrouter.ai/api/v1"

    # Backwards compatibility aliases
    GROQ_API_KEY: str = ""
    GROQ_BASE_URL: str = ""

    # ── Model Selection ──
    # For colab: use the HuggingFace model name (e.g. "Qwen/Qwen2.5-3B-Instruct")
    # For openrouter: use the OpenRouter model name (e.g. "qwen/qwen3.6-plus")
    BIG_MODEL: str = os.getenv("DEEPSEARCH_BIG_MODEL", "")
    SMALL_MODEL: str = os.getenv("DEEPSEARCH_SMALL_MODEL", "")

    # ── Rate Limiting ──
    MAX_REQUESTS_PER_MINUTE: int = int(os.getenv("MAX_RPM", "100"))
    MAX_TOKENS_PER_MINUTE: int = 40000
    RETRY_MAX_ATTEMPTS: int = 8
    RETRY_BASE_DELAY: float = 3.0

    # ── Search Settings ──
    MAX_SEARCH_RESULTS_PER_QUERY: int = 6
    MAX_CONTENT_LENGTH: int = 4000
    MAX_SEARCH_ROUNDS: int = 5
    MAX_SEARCHER_TOOLS_PER_ROUND: int = 4

    # ── Agent Settings ──
    MAX_REACT_ITERATIONS: int = 12
    FOCUS_SCORE_THRESHOLD: float = 4.0
    MIN_CONFIDENCE_SCORE: float = 0.3

    # ── Output ──
    OUTPUT_DIR: str = os.path.join(PROJECT_ROOT, "output")
    LOG_LEVEL: str = os.getenv("DEEPSEARCH_LOG_LEVEL", "INFO")

    @classmethod
    def _resolve_backend(cls):
        """Resolve API URL, key, and model names based on selected backend."""
        if cls.LLM_BACKEND == "colab":
            # Self-hosted vLLM backend
            if not cls.LLM_BASE_URL:
                raise ValueError(
                    "LLM_BASE_URL is not set!\n"
                    "Run the Colab notebook first and paste the ngrok URL.\n"
                    "Example: LLM_BASE_URL=https://abc123.ngrok-free.app/v1"
                )
            cls.GROQ_BASE_URL = cls.LLM_BASE_URL
            cls.GROQ_API_KEY = cls.LLM_API_KEY or "not-needed"
            cls.OPENROUTER_BASE_URL = cls.LLM_BASE_URL
            cls.OPENROUTER_API_KEY = cls.LLM_API_KEY or "not-needed"

            # Default model names for vLLM (HuggingFace format)
            if not cls.BIG_MODEL:
                cls.BIG_MODEL = "Qwen/Qwen2.5-3B-Instruct"
            if not cls.SMALL_MODEL:
                cls.SMALL_MODEL = cls.BIG_MODEL

            # Self-hosted = no rate limits
            cls.MAX_REQUESTS_PER_MINUTE = 1000
            cls.RETRY_BASE_DELAY = 1.0

        else:
            # OpenRouter cloud backend
            cls.GROQ_API_KEY = cls.OPENROUTER_API_KEY
            cls.GROQ_BASE_URL = cls.OPENROUTER_BASE_URL

            if not cls.BIG_MODEL:
                cls.BIG_MODEL = "qwen/qwen3.6-plus"
            if not cls.SMALL_MODEL:
                cls.SMALL_MODEL = cls.BIG_MODEL

    @classmethod
    def validate(cls):
        """Validate that required configuration is present."""
        cls._resolve_backend()

        if cls.LLM_BACKEND == "openrouter" and not cls.OPENROUTER_API_KEY:
            raise ValueError(
                "OPENROUTER_API_KEY is not set!\n"
                "Get a key at https://openrouter.ai\n"
                "Set it via: export OPENROUTER_API_KEY=your_key_here\n"
                "Or create a .env file in the DeepSearch directory."
            )
        os.makedirs(cls.OUTPUT_DIR, exist_ok=True)

        print(f"[OK] Backend: {cls.LLM_BACKEND}")
        print(f"[OK] Base URL: {cls.GROQ_BASE_URL}")
        print(f"[OK] Model: {cls.BIG_MODEL}")
